<xsl:stylesheet version="1.0"
		xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
<xsl:template match='id("W11")'>
Success
</xsl:template>
</xsl:stylesheet>
